# 📊 Task 2: Data Visualization and Storytelling

## 🎯 Objective:
To create a compelling Power BI dashboard using the Superstore dataset that delivers business insights through visual storytelling.

---

## 📁 Dataset:
- **Source:** SampleSuperstore.csv
- **Content:** Order-level data including sales, profit, discount, category, region, and sub-category information.

---

## 🛠 Tools Used:
- **Power BI Desktop**

---

## 📊 Report Structure:

### 📘 Page 1: Sales Overview
- **Bar Chart:** Sales by Region
- **Pie Chart:** Sales Distribution by Category
- **Scatter Plot:** Sales vs Profit
- 📌 Focus: High-level trends and geographic/business unit performance

### 📘 Page 2: Top Products Analysis
- **Table:** Top 10 Products by Sales
- 📌 Focus: Identifying high-performing products contributing most to revenue

### 📘 Page 3: Summary & Business Insights
- **Text Summary:** Key findings, performance gaps, and business recommendations

---

## 💡 Key Business Insights:
- 📈 **Technology** category leads in sales and profitability.
- 🌍 **West** region generates the highest total sales.
- ❗ **Tables** sub-category shows negative profits despite strong sales.
- 🔻 High discounts often reduce profit margins.
- 🏆 Top-selling products include **Binders**, **Phones**, and **Chairs**.

---

## 📤 Deliverables:
- **PowerBI_Visualization_Report.pdf** – exported PDF of the Power BI dashboard
- **SampleSuperstore.csv** – dataset used
- This `README.md` file

---

## ✅ Outcome:
Mastered data storytelling and business reporting using Power BI, focusing on visual clarity, actionable insights, and professional documentation.
